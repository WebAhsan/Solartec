<?php
/**
 * solartec functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package solartec
 */

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function solartec_setup() {
	/*
		* Make theme available for translation.
		* Translations can be filed in the /languages/ directory.
		* If you're building a theme based on solartec, use a find and replace
		* to change 'solartec' to the name of your theme in all the template files.
		*/
	load_theme_textdomain( 'solartec', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
		* Let WordPress manage the document title.
		* By adding theme support, we declare that this theme does not use a
		* hard-coded <title> tag in the document head, and expect WordPress to
		* provide it for us.
		*/
	add_theme_support( 'title-tag' );

	/*
		* Enable support for Post Thumbnails on posts and pages.
		*
		* @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		*/
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'menu-1' => esc_html__( 'Primary', 'solartec' ),
		)
	);

	/*
		* Switch default core markup for search form, comment form, and comments
		* to output valid HTML5.
		*/
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'solartec_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);
}
add_action( 'after_setup_theme', 'solartec_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function solartec_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'solartec_content_width', 640 );
}
add_action( 'after_setup_theme', 'solartec_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */

function solartec_widgets_init()
{
    register_sidebar([
        "name" => esc_html__('Footer-1', 'solartec'),
        "id" => 'footer-1',
		'description'   => esc_html__( 'Add footer widget', 'solartec' ),
		'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h5 class="text-white mb-4">',
		'after_title'   => '</h5>',
    ]);
    register_sidebar([
        "name" => esc_html__("Footer-2", "solartec"),
		'id'            => 'footer-2',
		'description'   => esc_html__( 'Add footer widget', 'solartec' ),
		'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h5 class="text-white mb-4">',
		'after_title'   => '</h5>',
    ]);
    register_sidebar([
        "name" => esc_html__("Footer-3", "solartec"),
        "id" => "footer-3",
        "description" => esc_html__("Add footer widget here.", "solartec"),
        "before_widget" => '<section id="%1$s" class="widget %2$s">',
        "after_widget" => "</section>",
        "before_title" => '<h5 class="text-white mb-4">',
        "after_title" => "</h5>",
    ]);
    register_sidebar([
        "name" => esc_html__("Footer-4", "solartec"),
        "id" => "footer-4",
        "description" => esc_html__("Add footer widget here.", "solartec"),
        "before_widget" => '<section id="%1$s" class="widget %2$s">',
        "after_widget" => "</section>",
        "before_title" => '<div class="section-title section-title-sm position-relative pb-3 mb-4">
        <h3 class="text-light mb-0">',
        "after_title" => "</h3></div>",
    ]);
}
add_action("widgets_init", "solartec_widgets_init");







/**
 * Enqueue scripts and styles.
 */
function solartec_scripts() {
	wp_enqueue_style( 'solartec-style', get_stylesheet_uri(), array(),_S_VERSION );
	wp_style_add_data( 'solartec-style', 'rtl', 'replace' );

	wp_enqueue_style( 'gstatic-css','https://fonts.gstatic.com', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'font-css','https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500&family=Roboto:wght@500;700;900&display=swap', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'cloudflare-css','https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'bootstrap-css','https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'animate-css',get_template_directory_uri() .'/assets/lib/animate/animate.min.css', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'owlcarousel-css',get_template_directory_uri() .'/assets/lib/owlcarousel/assets/owl.carousel.min.css', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'lightbox-css',get_template_directory_uri() .'/assets/lib/lightbox/css/lightbox.min.css', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'bootstrap-min-css',get_template_directory_uri() .'/assets/css/bootstrap.min.css', array(), '1.0.0', 'all' );
	wp_enqueue_style( 'main-css',get_template_directory_uri() .'/assets/css/main.css', array(), '1.0.0', 'all' );


	
	wp_enqueue_script( 'jquery-js', 'https://code.jquery.com/jquery-3.4.1.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'wow-js', get_template_directory_uri() . '/assets/lib/wow/wow.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'easing-js', get_template_directory_uri() . '/assets/lib/easing/easing.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'waypoints-js', get_template_directory_uri() . '/assets/lib/waypoints/waypoints.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'counterup-js', get_template_directory_uri() . '/assets/lib/counterup/counterup.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'owlcarousel-js', get_template_directory_uri() . '/assets/lib/owlcarousel/owl.carousel.min.js', array(), '1.0.0', true );
	wp_enqueue_script( 'isotope-js', get_template_directory_uri() . '/assets/lib/isotope/isotope.pkgd.min.js', array(), '1.0.0', true );

	wp_enqueue_script( 'main-js', get_template_directory_uri() . '/assets/js/main.js', array(), '1.0.0', true );


	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'solartec_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Custom Post Type.
 */
require get_template_directory() . '/inc/CPT/bellast-cpt.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

/**
 * Solartec Options Page
 */

if( function_exists('acf_add_options_page') ) {
    acf_add_options_page();
}

/**
 * Solartec Bootstrap Navwalker
 */

if ( ! file_exists( get_template_directory() . '/inc/class-wp-bootstrap-navwalker.php' ) ) {
    // File does not exist... return an error.
    return new WP_Error( 'class-wp-bootstrap-navwalker-missing', __( 'It appears the class-wp-bootstrap-navwalker.php file may be missing.', 'wp-bootstrap-navwalker' ) );
} else {
    // File exists... require it.
    require_once get_template_directory() . '/inc/class-wp-bootstrap-navwalker.php';
}

/**
 * Solartec Plugin Activation
 */
require get_template_directory() . '/inc/solartec-plugin-activation.php';

/**
 * Solartec Demo Import
 */
require get_template_directory() . '/inc/solartec-demo/solartec-demo-content.php';


/**
 * Remove Jquery Migrate Notice
 */
function remove_jquery_migrate_notice() {
    $m= $GLOBALS['wp_scripts']->registered['jquery-migrate'];
    $m->extra['before'][]='temp_jm_logconsole = window.console.log; window.console.log=null;';
    $m->extra['after'][]='window.console.log=temp_jm_logconsole;';
}
add_action( 'init', 'remove_jquery_migrate_notice', 5 );


/**
 * Disable Gutenberg Title
 */
$title = apply_filters("widget_title", $instance["title"]);
// Disables the block editor from managing widgets in the Gutenberg plugin.
add_filter("gutenberg_use_widgets_block_editor", "__return_false");
// Disables the block editor from managing widgets.
add_filter("use_widgets_block_editor", "__return_false");



class Solartec_gallery_Widget extends WP_Widget
{
    function __construct()
    {
        parent::__construct(
            "solartec-gallery-widget", // Base ID
            "Solartec Gallery Widget" // Name
        );

        add_action("widgets_init", function () {
            register_widget("Solartec_gallery_Widget");
        });
    }

    public $args = [
        "before_widget" => '<div class="widget-wrap">',
        "after_widget" => "</div></div>",
    ];

    public function widget($args, $instance)
    {
        echo $args["before_widget"];

        if (!empty($instance["title"])) {
            echo $args["before_title"] .
                apply_filters("widget_title", $instance["title"]) .
                $args["after_title"];
        }

        $widget_id = "widget_" . $args["widget_id"];

        // add image to after_widget
        $solartec_gallerys = get_field("solartec_gallery", $widget_id);
        ?>

		<div class="row g-2">
			<?php 
			foreach($solartec_gallerys as $solartec_gallery){
			?>
			<div class="col-4">
				<img class="img-fluid rounded" src="<?php echo $solartec_gallery['url']; ?>" alt="">
			</div>
			<?php } ?>
		</div>


        
		<?php echo $args["after_widget"];
    }

    public function form($instance)
    {
        $title = !empty($instance["title"])
            ? $instance["title"]
            : esc_html__("", "bellast"); ?>
        <p>
        <label for="<?php echo esc_attr(
            $this->get_field_id("title")
        ); ?>"><?php echo esc_html__("Title:", "text_domain"); ?></label>
            <input class="widefat" id="<?php echo esc_attr(
                $this->get_field_id("title")
            ); ?>" name="<?php echo esc_attr($this->get_field_name("title")); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <?php
    }

    public function update($new_instance, $old_instance)
    {
        $instance = [];

        $instance["title"] = !empty($new_instance["title"])
            ? strip_tags($new_instance["title"])
            : "";
        return $instance;
    }
}
$solartec_gallery_Widget = new Solartec_gallery_Widget();
