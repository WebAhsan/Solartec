<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package solartec
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->

    <?php 
    $header_location = get_field('header_location', 'option');
    $date_and_time = get_field('date_and_time', 'option');
    $header_phone = get_field('header_phone', 'option');
    $header_socials = get_field('header_social', 'option');
    $header_button = get_field('header_button', 'option');
    $header_button_url = get_field('header_button_url', 'option');
    ?>
    <!-- Topbar Start -->
    <div class="container-fluid bg-dark p-0">
        <div class="row gx-0 d-none d-lg-flex">
            <div class="col-lg-7 px-5 text-start">
                <div class="h-100 d-inline-flex align-items-center me-4">
                    <small class="fa fa-map-marker-alt text-primary me-2"></small>
                    <small><?php echo  $header_location; ?></small>
                </div>
                <div class="h-100 d-inline-flex align-items-center">
                    <small class="far fa-clock text-primary me-2"></small>
                    <small><?php echo  $date_and_time; ?></small>
                </div>
            </div>
            <div class="col-lg-5 px-5 text-end">
                <div class="h-100 d-inline-flex align-items-center me-4">
                    <small class="fa fa-phone-alt text-primary me-2"></small>
                    <small><?php echo  $header_phone; ?></small>
                </div>
                <div class="h-100 d-inline-flex align-items-center mx-n2">
                    <?php 
                    foreach($header_socials as $header_social){
                    
                    ?>
                    <a class="btn btn-square btn-link rounded-0 border-0 border-end border-secondary" href="<?php echo $header_social['social_url']['url']; ?>"><i class="<?php echo $header_social['social_icon']; ?>"></i></a>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top p-0">
        <div class="navbar-brand d-flex align-items-center border-end px-4 px-lg-5">
            <h2 class="m-0 text-primary">	
			<?php
			the_custom_logo();
			if ( is_front_page() && is_home() ) :
				?>
				<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
				<?php
			else :
				?>
				<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
				<?php
			endif;
			$solartec_description = get_bloginfo( 'description', 'display' );
			if ( $solartec_description || is_customize_preview() ) :
				?>
				<p class="site-description"><?php echo $solartec_description; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
			<?php endif; ?></h2>
			</div>
        <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'menu-1',
					'menu_class'        => 'navbar-nav ms-auto p-4 p-lg-0',
					'container'        => '<div>',
					'container_class'        => 'navbar-nav ms-auto p-4 p-lg-0',
                    'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
                    'walker'          => new WP_Bootstrap_Navwalker(),
                    'depth'           => 3, 
				)
			);
			?>
            <a href="<?php echo $header_button_url['url']; ?>" class="btn btn-primary rounded-0 py-4 px-lg-5 d-none d-lg-block"><?php echo $header_button; ?><i class="fa fa-arrow-right ms-3"></i></a>
        </div>
    </nav>