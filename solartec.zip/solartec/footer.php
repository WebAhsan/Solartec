<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package solartec
 */

?>

 <!-- Footer Start -->
 <div class="container-fluid bg-dark text-body footer mt-5 pt-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-3 col-md-6">
                <?php if (is_active_sidebar("footer-1")) {
                    dynamic_sidebar("footer-1");
                } ?>

                </div>
                <div class="col-lg-3 col-md-6">
                <?php
                    if ( is_active_sidebar( "footer-2" ) ) {
                      dynamic_sidebar("footer-2"); 
                    }
                     ?>
                </div>
                <div class="col-lg-3 col-md-6">
                <?php
                    if ( is_active_sidebar( "footer-3" ) ) {
                      dynamic_sidebar("footer-3"); 
                    }
                     ?>
                </div>
                <div class="col-lg-3 col-md-6">
                <?php
                    if ( is_active_sidebar( "footer-4" ) ) {
                      dynamic_sidebar("footer-4"); 
                    }
                     ?>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="copyright">
                <div class="row">
                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                        <?php echo get_field('footer_copyright','option'); ?>
                    </div>
                    <div class="col-md-6 text-center text-md-end">
                        <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
                        <?php if(get_field('designed_by','option')){ ?>
                        Designed By <?php echo get_field('designed_by','option'); ?>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded-circle back-to-top"><i class="bi bi-arrow-up"></i></a>

<?php wp_footer(); ?>

</body>
</html>
