<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package solartec
 */

get_header();
$show_breadcrumb = get_field('show_breadcrumb');
if( $show_breadcrumb == 'Show'){
?>
    <!-- Page Header Start -->

    <div class="container-fluid page-header py-5 mb-5">
        <div class="container py-5">
            <h1 class="display-3 text-white mb-3 animated slideInDown"><?php  echo get_the_title();?></h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a class="text-white" href="<?php echo home_url('/'); ?>">Home</a></li>
                    <li class="breadcrumb-item text-white active" aria-current="page"><?php  echo get_the_title();?></li>
                </ol>
            </nav>
        </div>
    </div>
<?php } ?>
    <!-- Page Header End -->
<?php the_content();?>

<?php
get_footer();
