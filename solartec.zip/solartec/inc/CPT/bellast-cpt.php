<?php
function bellast_slider_init() {
    $labels = array(
        'name'                  => _x( 'Slider','bellast'),
        'singular_name'         => _x( 'Slider',  'bellast' ),
        'menu_name'             => _x( 'Slider', 'Admin Menu text', 'bellast' ),
        'name_admin_bar'        => _x( 'Slider', 'Add New on Toolbar', 'bellast' ),
        'add_new'               => __( 'Add New Slider', 'bellast' ),
        'add_new_item'          => __( 'Add New Slider', 'bellast' ),
        'new_item'              => __( 'New Slider', 'bellast' ),
        'edit_item'             => __( 'Edit Slider', 'bellast' ),
        'view_item'             => __( 'View Slider', 'bellast' ),
        'all_items'             => __( 'All Slider', 'bellast' ),
        'search_items'          => __( 'Search Slider', 'bellast' ),
        'parent_item_colon'     => __( 'Parent Slider:', 'bellast' ),
        'not_found'             => __( 'No Slider found.', 'bellast' ),
        'not_found_in_trash'    => __( 'No Slider found in Trash.', 'bellast' ),
        'featured_image'        => _x( 'Slider Cover Image','bellast' ),
    );
 
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'slider' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor','thumbnail' ),
    );
 
    register_post_type( 'solar_slider', $args );

    $labels = array(
        'name'                  => _x( 'Our Project','bellast'),
        'singular_name'         => _x( 'Our Project',  'bellast' ),
        'menu_name'             => _x( 'Our Project', 'Admin Menu text', 'bellast' ),
        'name_admin_bar'        => _x( 'Our Project', 'Add New on Toolbar', 'bellast' ),
        'add_new'               => __( 'Add New Project', 'bellast' ),
        'add_new_item'          => __( 'Add New Project', 'bellast' ),
        'new_item'              => __( 'New Project', 'bellast' ),
        'edit_item'             => __( 'Edit Project', 'bellast' ),
        'view_item'             => __( 'View Project', 'bellast' ),
        'all_items'             => __( 'All Project', 'bellast' ),
        'search_items'          => __( 'Search Project', 'bellast' ),
        'parent_item_colon'     => __( 'Parent Project:', 'bellast' ),
        'not_found'             => __( 'No Project found.', 'bellast' ),
        'not_found_in_trash'    => __( 'No Project found in Trash.', 'bellast' ),
        'featured_image'        => _x( 'Project Cover Image','bellast' ),
    );
 
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'project' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title','thumbnail' ),
    );
 
    register_post_type( 'solar_project', $args );
}
 
add_action( 'init', 'bellast_slider_init' );

function solar_taxonomy() {
    register_taxonomy( 'project_category', 'solar_project', array(
        'label'        => __( 'Category', 'bellast' ),
        'hierarchical' => true,
    ) );

}
add_action( 'init', 'solar_taxonomy', 0 );